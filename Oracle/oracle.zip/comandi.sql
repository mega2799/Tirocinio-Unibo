
alter table "A" add constraint PK primary key("AK") 

alter table "B" add constraint PKB primary key("BK") 

-- Aggiungere il constraint per FAK

ALTER TABLE B
  ADD CONSTRAINT FK_A_constr FOREIGN KEY (FAK)     
      REFERENCES A(AK)
      ON DELETE CASCADE;

--Indici

CREATE UNIQUE INDEX A_AK ON A (AK ASC);
CREATE INDEX A_A4 ON A (A4 ASC);
CREATE INDEX A_A5 ON A (A5 ASC);
CREATE INDEX A_A6 ON A (A6 ASC);
CREATE UNIQUE INDEX B_BK ON B (BK ASC);
CREATE INDEX B_B4 ON B (B4 ASC);
CREATE INDEX B_B5 ON B (B5 ASC);
CREATE INDEX B_B6 ON B (B6 ASC);
CREATE INDEX B_FK ON B (FAK ASC);

--Ridurre la cache del client di sistema

ALTER SYSTEM SET CLIENT_RESULT_CACHE_SIZE = 0M SCOPE=SPFILE;
